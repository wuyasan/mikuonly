<template>
  <div>
    <!-- =================== 桌面版布局：保持你原来的效果 =================== -->
    <div
        class="conduct_child conduct_child--desktop"
        style="position: absolute;height: 90vh;width: 90vh;left: 90vh;top: 5vh;"
    >
      <div class="title">
        <img
            src="/nc.png"
            style="position: absolute;width: 42vh;top: -10vh;left: 19vh;
                 filter: contrast(300%) brightness(752%) invert(100%);
                 opacity: 0.5;"
        >
        <div
            class="heading"
            style="position: absolute;bottom: 90%;left: 55%;
                 font-family: font5;font-size: 8vh;font-weight: 900;
                 line-height: 6.2vh;text-align:left;color: white;opacity:0.4;"
        >
          AGE<br>POLICY
        </div>
        <div
            class="heading"
            style="position: absolute;bottom: 85%;left: 55%;
                 font-family: font5;font-size: 1.2vh;font-weight: 900;
                 line-height: 6.2vh;text-align:left;color: white;
                 letter-spacing: 1.3vh;width:100%;opacity:0.4;"
        >
          MIKU ONLY 2026
        </div>
      </div>

      <div
          class="floorpanel1 frosted-panel"
          style="position: absolute;height: 72%;top: 13vh;
               mix-blend-mode: screen;width:70vh;left: 17%;overflow:auto;"
      >
        <horizontalttl />

        <div
            class="age-policy-text"
            style="position:absolute;inset:0;
                 margin:2vh 3vh 4vh 3vh;padding:3vh 4vh 6vh 4vh;
                 color:white;font-size:1.6vh;line-height:2.5vh;"
        >
          <!-- Admission Age Rules -->
          <div style="font-family:font5;font-size:2vh;font-weight:900;margin-bottom:1vh;">
            Admission Age Rules
          </div>
          <div style="margin-bottom:2vh;">
            This is an <span style="font-weight:900;">All Ages</span> event.
            There is <span style="font-weight:900;">no adult content</span>,
            and <span style="font-weight:900;">no alcohol</span> will be served.
          </div>

          <!-- Minors & Supervision -->
          <div style="font-family:font5;font-size:2vh;font-weight:900;margin-bottom:1vh;">
            Minors &amp; Supervision
          </div>
          <ul style="margin:0 0 2vh 2.5vh;padding:0;">
            <li style="margin-bottom:1vh;">
              <span style="font-weight:900;">Age 12 and under (including age 12):</span>
              Must be accompanied at all times by a parent, legal guardian,
              or responsible adult <span style="font-weight:900;">18 years or older</span>.
              The guardian must hold a valid ticket and remain reachable on-site
              (phone available).
            </li>
            <li style="margin-bottom:1vh;">
              <span style="font-weight:900;">Ages 13–17:</span>
              May attend unaccompanied
              <span style="font-weight:900;">if permitted by the Parent</span>. No need to be permitted by the Organizer.
              However, it is strongly recommended that a parent or guardian
              accompany the minor or remain nearby or reachable.
            </li>
            <li style="margin-bottom:1vh;">
              The Organizer <span style="font-weight:900;">does not</span> assume custodial
              responsibility for minors. Parents or guardians are fully responsible
              for the minor’s conduct, safety, and personal belongings.
            </li>
          </ul>

          <!-- ID Check & Wristbands -->
          <div style="font-family:font5;font-size:2vh;font-weight:900;margin-bottom:1vh;">
            ID Check &amp; Wristbands
          </div>
          <ul style="margin:0 0 2vh 2.5vh;padding:0;">
            <li style="margin-bottom:1vh;">
              Attendees may be required to present a valid photo ID or other
              documentation showing date of birth upon entry.
            </li>
            <li style="margin-bottom:1vh;">
              Wristbands may be issued for age grouping/ticket group, re-entry identification,
              and general event management.
            </li>
            <li style="margin-bottom:1vh;">
              Refusal to comply with verification, providing false information,
              or misuse of IDs or wristbands may result in denied entry or
              removal from the event.
            </li>
          </ul>

          <!-- Safety & Removal -->
          <div style="font-family:font5;font-size:2vh;font-weight:900;margin-bottom:1vh;">
            Safety &amp; Removal
          </div>
          <ul style="margin:0 0 2vh 2.5vh;padding:0;">
            <li>
              Disruptive behavior, harassment, unsafe conduct, or failure to follow
              staff instructions may result in
              <span style="font-weight:900;">immediate removal</span>, typically
              without refund (subject to ticketing terms).
            </li>
            <li>
              For any questions, please contact us via our official email info@ny-miku-only.com or
              official social media channels.
            </li>
          </ul>
        </div>
      </div>

      <div
          class="bottomline"
          style="position: absolute;width: 76.1vh;height: 0.1vh;
               background: rgb(255 255 255);left: 16vh;"
      ></div>
    </div>

    <!-- =================== 手机版布局：竖排 + 可滚动 =================== -->
    <div class="conduct_child-mobile">
      <div class="mobile-title">
        <img src="/nc.png" class="mobile-title-img">
        <div class="mobile-heading-main">AGE&nbsp;POLICY</div>
        <div class="mobile-heading-sub">MIKU ONLY 2026</div>
      </div>

      <div class="mobile-panel frosted-panel">
        <horizontalttl />

        <div class="mobile-age-text">
          <!-- Admission Age Rules -->
          <div class="mobile-section-title">
            Admission Age Rules
          </div>
          <p>
            This is an <strong>All Ages</strong> event.
            There is <strong>no adult content</strong>,
            and <strong>no alcohol</strong> will be served.
          </p>

          <!-- Minors & Supervision -->
          <div class="mobile-section-title">
            Minors &amp; Supervision
          </div>
          <ul>
            <li>
              <strong>Age 12 and under (including age 12):</strong>
              Must be accompanied at all times by a parent, legal guardian,
              or responsible adult <strong>18 years or older</strong>.
              The guardian must hold a valid ticket and remain reachable on-site
              (phone available).
            </li>
            <li>
              <strong>Ages 13–17:</strong>
              May attend unaccompanied
              <strong>if permitted by the Parent</strong>.
              No need to be permitted by the Organizer.
              However, it is strongly recommended that a parent or guardian
              accompany the minor or remain nearby or reachable.
            </li>
            <li>
              The Organizer <strong>does not</strong> assume custodial
              responsibility for minors. Parents or guardians are fully responsible
              for the minor’s conduct, safety, and personal belongings.
            </li>
          </ul>

          <!-- ID Check & Wristbands -->
          <div class="mobile-section-title">
            ID Check &amp; Wristbands
          </div>
          <ul>
            <li>
              Attendees may be required to present a valid photo ID or other
              documentation showing date of birth upon entry.
            </li>
            <li>
              Wristbands may be issued for age grouping/ticket group, re-entry identification,
              and general event management.
            </li>
            <li>
              Refusal to comply with verification, providing false information,
              or misuse of IDs or wristbands may result in denied entry or
              removal from the event.
            </li>
          </ul>

          <!-- Safety & Removal -->
          <div class="mobile-section-title">
            Safety &amp; Removal
          </div>
          <ul>
            <li>
              Disruptive behavior, harassment, unsafe conduct, or failure to follow
              staff instructions may result in
              <strong>immediate removal</strong>, typically
              without refund (subject to ticketing terms).
            </li>
            <li>
              For any questions, please contact us via our official email
              <strong>info@ny-miku-only.com</strong> or
              official social media channels.
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import horizontalttl from './horizontalttl.vue'

export default {
  components: { horizontalttl },
}
</script>

<style>
/* ===== PC: 原有动画 & 样式（不动） ===== */
.bottomline {
  animation-name: bottomline;
  animation-delay: 0s;
  animation-duration: 0.3s;
  animation-iteration-count: 1;
  animation-timing-function: cubic-bezier(1, 0.02, 0.17, 1);
  animation-fill-mode: forwards;
}

@keyframes bottomline {
  0% {
    opacity: 0;
    bottom: 17%;
  }
  100% {
    opacity: 1;
    bottom: 12%;
  }
}

.frosted-panel {
  background: rgba(0, 0, 0, 0.45);
  border-radius: 1.5vh;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 0.8vh 2vh rgba(0, 0, 0, 0.4);
}

.content {
  animation-name: content;
  animation-delay: 0.8s;
  animation-duration: 0.7s;
  animation-iteration-count: 1;
  animation-timing-function: cubic-bezier(1, 0.02, 0.17, 1);
  animation-fill-mode: forwards;
}

@keyframes content {
  0% {
    opacity: 0;
    width: 90%;
  }
  100% {
    opacity: 1;
    width: 100%;
  }
}

/* 默认：只显示桌面版，隐藏手机版 */
.conduct_child-mobile {
  display: none;
}
/* ========= conduct_child：移动端布局 ========= */
@media (max-width: 768px) {
  .conduct_child {
    position: relative !important;
    left: 0 !important;
    top: 0 !important;
    width: 100vw !important;
    height: auto !important;
    padding: 10vh 4vw 6vh;
  }

  /* 顶部图和标题居中缩放一点 */
  .conduct_child .title img {
    width: 30vh !important;
    left: 50% !important;
    top: -6vh !important;
    transform: translateX(-50%);
    opacity: 0.35 !important;
  }

  .conduct_child .heading {
    left: 50% !important;
    transform: translateX(-50%);
    text-align: center !important;
    line-height: 4.2vh !important;
  }

  .conduct_child .title .heading:nth-of-type(1) {
    top: 0.5vh !important;
    bottom: auto !important;
    font-size: 4.2vh !important;
  }

  .conduct_child .title .heading:nth-of-type(2) {
    top: 5.5vh !important;
    bottom: auto !important;
    font-size: 1.6vh !important;
    letter-spacing: 0.6vh !important;
    opacity: 0.6 !important;
  }

  /* 主内容 panel：变成窄一点的深色玻璃，中间浮着 */
  .conduct_child .floorpanel1 {
    position: relative !important;
    top: 10vh !important;
    left: 50% !important;
    transform: translateX(-50%);
    width: 92vw !important;
    height: auto !important;
    max-height: none !important;
    margin-bottom: 4vh !important;

    background: rgba(0, 0, 0, 0.55) !important;
    mix-blend-mode: normal !important;
    border-radius: 1.5vh !important;
    box-shadow: 0 1.6vh 3vh rgba(0, 0, 0, 0.6) !important;
    backdrop-filter: blur(18px) !important;
    -webkit-backdrop-filter: blur(18px) !important;
  }

  .conduct_child .age-policy-text {
    position: relative !important;
    margin: 2.2vh 2.4vh 2.6vh 2.4vh !important;
    padding: 2.4vh 2.4vh 3vh 2.4vh !important;
    font-size: 1.55vh !important;
    line-height: 2.4vh !important;
    color: #ffffff !important;
  }

  .conduct_child .age-policy-text ul {
    margin-bottom: 1.6vh !important;
  }

  .conduct_child .age-policy-text li {
    margin-bottom: 0.8vh !important;
  }

  /* 底部横线占满宽度 */
  .conduct_child .bottomline {
    position: relative !important;
    width: 100% !important;
    left: 0 !important;
    bottom: 0 !important;
    margin-top: 1vh;
  }
}

</style>
